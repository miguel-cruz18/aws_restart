'''
Working with Loops
'''

#Informing the user about the script
print("Count to 10!")

#Writing the for loop
for x in range (0, 11):
    print(x)
